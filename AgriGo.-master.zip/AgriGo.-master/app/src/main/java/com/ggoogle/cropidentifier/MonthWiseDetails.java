package com.ggoogle.cropidentifier;

import java.util.List;

public class MonthWiseDetails {
    private String month;
    private String cropName;

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }
}
