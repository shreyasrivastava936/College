package com.ggoogle.cropidentifier;

public class AppConfig {
    public static final String IMAGE_DIRECTORY_NAME = "image_from_app";
    public static final String SELECT_GALLERY_IMAGE = "select image from gallery";
    public static final String TAKE_PHOTO_USING_CAMERA = "take photo using camera";
}
